$(document).ready(function(){
    $('.manual_btn').click(function(){
        $('.manual_item').toggleClass('manual_show');
    });
    
});