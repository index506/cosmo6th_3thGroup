function cancel(){
	alert("취소합니다.");
	location.href="../../index.html";
}
