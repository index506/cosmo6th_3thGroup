function search_click() {
    alert("검색을 시작합니다");
}